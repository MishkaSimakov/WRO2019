@include('partials.header')

<h1 class="header">Подтверждение постов</h1>

@foreach($posts as $post)
  <h2 class="list"><a title="{{ $post->mac_address }}" href="{{ $post->confirmUrl }}">{{ $post->name }}</a></h2>
@endforeach

@include('partials.footer')