<?php

namespace App;

use function compact;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use function optional;
use function route;
use function var_dump;

class Sensor extends Model
{
    protected $fillable = ['min_value', 'max_value', 'name'];

    static function getId(Request $request) {
        $sensor_id = optional(Sensor::where('model', $request->sensor_name))->id;

        if (!$sensor_id) {
            $sensor = Sensor::make();

            $sensor->name = $request->sensor_name;
            $sensor->model = $request->sensor_name;

            $sensor->save();

            $sensor_id = $sensor->id;
        }

        return $sensor_id;
    }
}
