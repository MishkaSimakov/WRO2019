<?php

namespace App\Http\Controllers;

use App\Archive;
use App\Channel;
use App\Current;
use App\Post;
use App\Sensor;
use App\Unit;
use App\Untrusted_post;
use function compact;
use function dd;
use function GuzzleHttp\Promise\all;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Khill\Lavacharts\Lavacharts;
use function max;
use function min;
use function var_dump;
use function view;

class PostController extends Controller
{
    public function index(Request $request)
    {
        $posts = Post::all();

        if ($request->name) {
            $posts = $posts->where('name', $request->name);
        }

        return view('posts.index', compact('posts'));
    }

    public function show(Post $post)
    {
        $post->load('archives.channel.sensor');

        foreach ($post->channels as $channel) {
            $graph[$channel->id] = $channel->graph;
        }

        return view('posts.show', compact('post', 'lava'));
    }

    public function create(Request $request)
    {
        $post = Post::make();

        $post->name = $request->name;

        $post->save();

        return redirect(route('create'));
    }

    public function confirmation()
    {
        $posts = Untrusted_post::all();

        return view('posts.confirmation', compact('posts'));
    }

    public function confirm(Untrusted_post $untrusted_post)
    {
        Untrusted_post::destroy($untrusted_post->id);

        $post = Post::make();

        $post->name = $untrusted_post->name;
        $post->mac_address = $untrusted_post->mac_address;

        $post->save();

        return redirect(route('posts.show', compact('post')));
    }
}